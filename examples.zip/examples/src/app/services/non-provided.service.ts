import { Injectable } from '@angular/core';

@Injectable()
export class NonProvidedService {

  public constructor() { }

}
