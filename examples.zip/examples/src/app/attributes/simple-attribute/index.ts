export * from './simple-attribute.component';
