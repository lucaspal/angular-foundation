export * from './bindings-attribute.component';
