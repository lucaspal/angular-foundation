export * from './interpolation.component';
