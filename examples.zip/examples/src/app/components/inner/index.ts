export * from './inner.component';
