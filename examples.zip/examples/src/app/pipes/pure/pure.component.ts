import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pure',
  templateUrl: './pure.component.html',
  styleUrls: ['./pure.component.css']
})
export class PureComponent {

  public noop() {
  }

}
