export * from './case-study.component';
