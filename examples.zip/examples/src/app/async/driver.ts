export interface Driver {
    driverId: string;
    permanentNumber: string;
    code: string;
    givenName: string;
    familyName: string;
}