export class Center {
    constructor(public readonly latitude: number, public readonly longitude: number, public readonly zoom?:number) {
    }
}