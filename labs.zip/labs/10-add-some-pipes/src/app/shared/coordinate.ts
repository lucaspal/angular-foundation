export interface Coordinate {
  lat: number;
  lng: number;
}
